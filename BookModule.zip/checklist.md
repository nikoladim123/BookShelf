Task 1: Format the content of our books
  Items to condiser:
    -Preface (optional)
    -Index (optional)
    -Page footers

Task 2: Create Links To books with prerequisite knowledge:
  -variables
  -Declarations (var, let, const)
  -Incrementing/Decrementing (++ & --)
  -Comparison Operators (<, >, ==, <=, >=)
  -Boolean

  <div class="page" data-density="soft">
      <div class="page-content">
        <h2 class="page-header">For Loop Breakdown</h2>
      </div>
    </div>