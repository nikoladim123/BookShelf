// let textEditor = document.getElementsByClassName('textEditor');
// textEditor.addEventListener('click',(e)=>{
//   e.preventDefault()
//   e.stopPropagation();
//   console.log(123)
// })

// pageFlip.on('flip', (e) => {
//         console.log("Current page: " + e.data);
//         e.stopPropagation();
//         // callback code
//     }
// );