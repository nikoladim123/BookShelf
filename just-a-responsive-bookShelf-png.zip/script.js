import {PageFlip} from 'page-flip';

const pageFlip = new PageFlip(document.getElementById('book1'),
    {
        width: 400,
        height: 600,
        size: "fixed"
    }
);

pageFlip.loadFromHTML(document.querySelectorAll('#book1'));
